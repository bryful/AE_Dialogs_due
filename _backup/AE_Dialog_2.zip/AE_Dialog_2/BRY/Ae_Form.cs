﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BRY
{
	public partial class Ae_Form : Form
	{
		private ContextMenuStrip cm = new ContextMenuStrip();
		private ToolStripMenuItem saveAsMenu = new ToolStripMenuItem();
		private ToolStripMenuItem showCodeMenu = new ToolStripMenuItem();


		private windowType _windowType = windowType.dialog;
		private bool _resizeable = false;
		private bool _center = true;

		public const string objNameDef = "winObj";
		private string _objName = objNameDef;

		public Ae_Form()
		{
			InitializeComponent();
			//メニューを追加
			showCodeMenu.Text = "ダイアログに表示";
			showCodeMenu.Click += new EventHandler(showCodeMenu_Click);

			cm.Items.Add(showCodeMenu);
			this.ContextMenuStrip = cm;
			if (_center == true)
			{
				this.StartPosition = FormStartPosition.CenterScreen;
			}
		}
		//------------------------------------------------------------------------------------------------------------
		private void showCodeMenu_Click(object sender, EventArgs e)
		{
			CodeDisp dlg = new CodeDisp();
			dlg.Code = GetScriptCode();
			dlg.ShowDialog();
		}
		
		//------------------------------------------------------------------------------------------------------------
		private string GetScriptCode()
		{
			string ret = "";

			string wt = "";
			switch (_windowType)
			{
				case windowType.floatingPalette:
				case windowType.paletet:
					wt = "palette";
					break;
				case windowType.dialog:
					wt = "dialog";
					break;
				case windowType.window:
					wt = "window";
					break;
			}

			string lines = Utils.GetControlsScriptCode(this);
			if (lines !="")
			{
				lines = "\t"+lines.Replace("\r\n", "\r\n\t");
			}
			string op = "";
			if (AE_resizeable)
			{
				op += "resizeable:true";
			}
			if (AE_maximizeButton)
			{
				if (op != "") op += ",";
				op += "maximizeButton:true";
			}
			if (AE_minimizeButton)
			{
				if (op != "") op += ",";
				op += "minimizeButton:true";
			}
			if (op != "") op = ",{" + op + "}";

			string ic = "";
			if(AE_isCenter)
			{
				ic = $"{AE_objName}.center();";
			}
			ret =
				$"(function(){{\r\n" +
				$"\tvar {AE_objName} = new Window(\"{wt}\",\"{AE_title}\" ,{Utils.GetBoundStr(this)} {op});\r\n" +
				$"\t{lines}\r\n"+
				$"\t{ic}\r\n" +
				$"\t{AE_objName}.show();\r\n" +
				"})();\r\n";

			return ret;


		}
	}
}
