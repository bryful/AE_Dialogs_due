﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;


namespace BRY
{
	public enum windowType
	{
		dialog = 0,
		paletet,
		floatingPalette,
		window,
	}
	public enum defaultElement
	{
		none = 0,
		ok,
		cancel
	}
	public enum iconbuttonStyle
	{
		button = 0,
		toolbutton
	}
	public enum borderStyle
	{
		black = 0,
		etched,
		gray,
		raised,
		sunken
	}
	public static class Utils
	{
		private static string[] windowTypeT = new string[]
		{
			"dialog",
			"paletet",
			"palette", //floatingPalette
			"window"
		};
		public static string windowTypeStr(windowType wt)
		{
			return windowTypeT[(int)wt];
		}
		//------------------------------------------------------------------------------------------------------------
		public static string RectToBounds(Rectangle rct)
		{
			string ret = "";
			ret += "[" + zero3(rct.Left) + ", " + zero3(rct.Top) + ", " + zero3(rct.Left) + "+" + zero3(rct.Width) + ", " + zero3(rct.Top) + "+" + zero3(rct.Height) + "]";
			return ret;
		}
		//------------------------------------------------------------------------------------------------------------
		public static string zero3(int v)
		{
			string ret = v.ToString();


			int l = ret.Length;

			if (l < 4)
			{
				for (int i = 0; i < (4 - l); i++)
				{
					ret = " " + ret;
				}
			}




			return ret;
		}
		//------------------------------------------------------------------------------------------------------------
		public static string GetBoundStr(Control sender)
		{
			Rectangle b = sender.Bounds;
			if ((sender.Parent is Panel_AE) || (sender.Parent is Group_AE) || (sender.Parent is GroupBox) || (sender.Parent is Panel))
			{
				b.Y -= 8;
			}
			return RectToBounds(b);
		}
		//------------------------------------------------------------------------------------------------------------
		public static int[] ToBounds(Control sender)
		{
			return new int[] { sender.Left, sender.Top, sender.Right, sender.Bottom };
		}
		//------------------------------------------------------------------------------------------------------------
		public static void FromBounds(int[] b, Control sender)
		{
			if (b.Length >= 4)
			{
				int v = 0;
				if (b[0] > b[2])
				{
					v = b[0];
					b[0] = b[2];
					b[2] = v;
				}
				if (b[1] > b[3])
				{
					v = b[1];
					b[1] = b[3];
					b[3] = v;
				}
			}
			if (b.Length >= 2)
			{
				sender.Location = new Point(b[0], b[1]);
			}
			if (b.Length >= 4)
			{
				sender.Size = new Size(b[2] - b[0], b[3] - b[1]);
			}
			//------------------------------------------------------------------------------------------------------------
		}
		public static Form GetForm(Control c)
		{
			Form ret = null;
			var p = c.Parent;
			while (p != null)
			{
				if (p is Form)
				{
					ret = (Form)p; 
					break;
				}
				p = p.Parent;
			}
			return ret;
		}
		public static string GetControlsScriptCode(Control ctrl)
		{
			string ret = "";
			if (ctrl.Controls.Count > 0)
			{
				foreach (Control c in ctrl.Controls)
				{
					string ss = "";
					if (c is Button_AE) {  ss =  ((Button_AE)c).ScriptCode; }
					else if (c is Checkbox_AE) { ss = ((Checkbox_AE)c).ScriptCode; }
					else if (c is Dropdownlist_AE) { ss = ((Dropdownlist_AE)c).ScriptCode; }
					else if (c is Edittext_AE) { ss = ((Edittext_AE)c).ScriptCode; }
					else if (c is Group_AE) { ss = ((Group_AE)c).GetScriptCode(); }
					else if (c is Iconbutton_AE) { ss = ((Iconbutton_AE)c).ScriptCode; }
					else if (c is Image_AE) { ss = ((Image_AE)c).ScriptCode; }
					else if (c is Listbox_AE) { ss = ((Listbox_AE)c).ScriptCode; }
					else if (c is Panel_AE) { ss = ((Panel_AE)c).GetScriptCode(); }
					else if (c is Progressbar_AE) { ss = ((Progressbar_AE)c).ScriptCode; }
					else if (c is Radiobutton_AE) { ss = ((Radiobutton_AE)c).ScriptCode; }
					else if (c is ScrollbarH_AE) { ss = ((ScrollbarH_AE)c).ScriptCode; }
					else if (c is ScrollbarV_AE) { ss = ((ScrollbarV_AE)c).ScriptCode; }
					else if (c is Slider_AE) { ss = ((Slider_AE)c).ScriptCode; }
					else if (c is Statictext_AE) { ss = ((Statictext_AE)c).ScriptCode; }

					if (ss != "") ret += ss;

				}
			}
			return ret;
		}
	}
}
