﻿namespace BRY
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナー変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナーで生成されたコード

		/// <summary>
		/// デザイナー サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディターで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.button_AE1 = new BRY.Button_AE();
			this.dropdownlist_AE1 = new BRY.Dropdownlist_AE();
			this.SuspendLayout();
			// 
			// button_AE1
			// 
			this.button_AE1.AE_bounds = new int[] {
        96,
        58,
        362,
        115};
			this.button_AE1.AE_objName = "button_AE1";
			this.button_AE1.AE_text = "";
			this.button_AE1.AE_textObjName = "";
			this.button_AE1.Font = new System.Drawing.Font("Tahoma", 8.25F);
			this.button_AE1.Image = null;
			this.button_AE1.Location = new System.Drawing.Point(96, 58);
			this.button_AE1.Name = "button_AE1";
			this.button_AE1.Size = new System.Drawing.Size(266, 57);
			this.button_AE1.TabIndex = 0;
			this.button_AE1.UseVisualStyleBackColor = true;
			// 
			// dropdownlist_AE1
			// 
			this.dropdownlist_AE1.AE_bounds = new int[] {
        191,
        185,
        312,
        206};
			this.dropdownlist_AE1.AE_index = -1;
			this.dropdownlist_AE1.AE_itemsName = "dropdownlist_AE1Items";
			this.dropdownlist_AE1.AE_objName = "dropdownlist_AE1";
			this.dropdownlist_AE1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.dropdownlist_AE1.Font = new System.Drawing.Font("Tahoma", 8.25F);
			this.dropdownlist_AE1.FormattingEnabled = true;
			this.dropdownlist_AE1.Location = new System.Drawing.Point(191, 185);
			this.dropdownlist_AE1.Name = "dropdownlist_AE1";
			this.dropdownlist_AE1.Size = new System.Drawing.Size(121, 21);
			this.dropdownlist_AE1.TabIndex = 3;
			// 
			// Form1
			// 
			this.AE_bounds = new int[] {
        0,
        0,
        668,
        345};
			this.AE_isCenter = false;
			this.AE_maximizeButton = false;
			this.AE_minimizeButton = false;
			this.AE_title = "Ae_script";
			this.AE_windowType = BRY.windowType.window;
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(652, 306);
			this.Controls.Add(this.dropdownlist_AE1);
			this.Controls.Add(this.button_AE1);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form1";
			this.ShowIcon = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
			this.Text = "Ae_script";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}

		#endregion

		private Button_AE button_AE1;
		private Dropdownlist_AE dropdownlist_AE1;
	}
}

