﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Reflection;

namespace BRY
{
	public partial class Form1 : Ae_Form
	{
		public Form1()
		{
			InitializeComponent();
			// DateTimeのプロパティ一覧を取得する
			PropertyInfo[] p = typeof(Control).GetProperties();

			// 取得した一覧をコンソールに出力する
			string s = "";
			foreach (var a in p)
			{
				if (a.CanWrite == true)
				{
					s += $"[Browsable(false)]\r\n";
					s += $"public new {a.PropertyType.ToString()} {a.Name}\r\n";
					s += $"{{\r\n";
					s += $"	get {{ return base.{a.Name}; }}\r\n";
					s += $"	set {{ base.{a.Name} = value; }}\r\n";
					s += "}\r\n";
				}
			}
			Clipboard.SetText(s);
		}

		private void dropdownlist_AE1_TextChanged(object sender, EventArgs e)
		{
		}

		private void Form1_Load(object sender, EventArgs e)
		{
		

		}

		private void button_AE2_Click(object sender, EventArgs e)
		{
			// DateTimeのプロパティ一覧を取得する
			PropertyInfo[] p = typeof(Button_AE).GetProperties();

			// 取得した一覧をコンソールに出力する
			string s = "";
			foreach (var a in p)
			{
				s +=   a.Name +"\r\n";
			}
			Clipboard.SetText(s);
		}
	}
}
